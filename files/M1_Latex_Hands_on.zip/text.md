# Cover page
A Very Interesting Supervised Project
Dr. Azer Ty \\ Pr. Oliver Leaf
MSc Natural Language Processing
Jane Doe

https://www.univ-lorraine.fr Université de Lorraine
https://idmc.univ-lorraine.fr/ L'Institut des Sciences du Digital, Management et Cognition

Supervised Project Report

Logos should have a width that is 30% of the line width.

---
# Acknowledgments
You can thank all the people who helped and supported you throughout the project.

---
# List of abbreviations
NLP Natural Language Processing
ML Machine Learning

---
# Chapter 1
About Latex

## Text formatting
You can use different strategies to format your text and draw readers' attention on special words: 
- important
- foreign word
- usually not frequently used in academic contexts
- practical to mention tools or commands
- colors are also to avoid in academic contexts, but can be used to color-code stuff

## Images
The NLP Master's take place at the IDMC Institut des sciences du Digital (see Figure 1).
It is part of the Université de Lorraine (see Figure 2).

Let's start a new page.

The IDMC logo should have a width that is 50% of the line width, and the UL logo 30% of the line width.

## More lists 
Ordered lists:

1. First step
2. Second step
3. Third step
4. Fourth step
	(a) Substep
        (b) Substep

We need some space (2cm).


Mix it up:
- Step
- Step
	1. one
	2. two
	3. three
- Step
- Step
	- a
	- b
	
### A subsection
You can even have \subsubsection.
In these ((sub)sub)sections, you can have different paragraphs, with or without indents.

## An empty section, but without a number
Just so you know it's(Actually, in academic reports and articles, you should not use contracted forms, so you should not write it's but it is) possible.

---
# Chapter 2
More Advanced Latex

In Chapter 1, we tried out very basic commands. Now, let's try slightly more advanced stuff.

## Equations
Even if you're not a fan of math, you may have to talk about some equations or formulas in your report. You can talk about them in-line, or in display mode.
	Even for very basic math, you can use it: 1 + 1 = 2, 10x, a², ...

∑nk=1 k2 = n(n+1)(2n+1)

Equations can be numbered, and use logic operators:
¬∃x.P(x) ∨ Q(x) ⇐⇒ ∀x.¬P(x) ∧ ¬Q(x)


See more at: https://www.overleaf.com/learn/latex/List_of_Greek_letters_and_math_symbols or in general on the https://www.overleaf.com/learn/ Overleaf website.

## Tables
You really can custom your tables, especially if you use extra packages. Let's stick to basic tables for now (try to really do them from scratch yourself). See Tables 1, 2, 3.

(create the tables)

## Citations
As you probably know, I am working on ethics in NLP. I am taking this opportunity to make you look up some articles that I like :).

Use the links in the Markdown file to find the bibtex entries.

Benjamin (2023) uses real-world examples to show how machine learning can perpetuate racism. 

Research on stereotypical bias starts to take interest in languages other than English (Malik et al, 2022). 

Different ways to cite!
Notice the different ways to cite and the associated citation commands!

Position papers are also very interesting and relevant in this subfield (Miceli, Posada, and Yang, 2022). VS 
The notion of power, as highlighted by Miceli, Posada, and Yang (2022), is crucial.

You can find the bibtex entries at the following URls:
- https://scholar.google.com/scholar?hl=fr&as_sdt=0%2C5&q=race+after+technology

-https://aclanthology.org/2022.naacl-main.76/

- https://dl.acm.org/doi/10.1145/3492853

---
# Appendix
Extra, interesting but not absolutely needed information

You may have to provide additional information: detailed results, detailed lists, more figures and tables, etc. 
